import { ArrowRight } from 'lucide-react';
import { 
  BareMetalServer, 
  Cloud, 
  Ai, 
  View, 
  Headphones, 
  Activity 
} from '@carbon/icons-react';
import { 
  DataScience,
  EventAutomation,
  Robotics,
  EdgeComputing
} from '@carbon/pictograms-react';

import { Link } from 'react-router-dom';
import Navigation from '../components/Navigation';
import Footer from '../sections/Footer';
import ClientLogos from '../sections/ClientLogos';
import Testimonials from '../sections/Testimonials';
import CaseStudies from '../sections/CaseStudies';
import About from '../sections/About';
import Delivery from '../sections/Delivery';
import Reliability from '../sections/Reliability';
import Partnerships from '../sections/Partnerships';
import Closing from '../sections/Closing';
import Contact from '../sections/Contact';
import Differentiator from '../sections/Differentiator';
import ErrorBoundary from '../components/ErrorBoundary';

/**
 * Cover - Main Homepage Layout
 * 
 * Strategic Services layout with custom Hero and Observability-style cards.
 */

// Trust Bar Component
const TrustBar = () => {
  return (
    <section className="py-6 bg-[#0F172A] border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-gray-400">
          <span>British-certified technologists</span>
          <span className="text-gray-600">|</span>
          <span>Huawei Enterprise Partner</span>
          <span className="text-gray-600">|</span>
          <span>EZY Distribution Alliance</span>
        </div>
      </div>
    </section>
  );
};

// Service Card Component (Observability-style for pillars)
interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: React.ReactNode;
  tags: string[];
  cta: string;
  ctaLink: string;
  badge?: string;
}

const ServiceCard = ({ icon, title, description, tags, cta, ctaLink, badge }: ServiceCardProps) => {
  return (
    <div className="group bg-white rounded-lg border border-gray-100 p-6 hover:border-blue-200 hover:shadow-xl transition-all duration-300">
      {/* Icon and Title */}
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center text-blue-500">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          {badge && (
            <span className={`inline-block px-2 py-0.5 text-[10px] font-semibold uppercase rounded mt-1 ${
              badge === 'Emerging' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
            }`}>
              {badge}
            </span>
          )}
        </div>
      </div>
      
      {/* Description with hover reveal */}
      <div className="text-sm text-gray-600 leading-relaxed">
        {description}
      </div>
      
      {/* Tags */}
      <div className="flex flex-wrap gap-2 mb-5 mt-4">
        {tags.map((tag) => (
          <span key={tag} className="px-2.5 py-1 text-[10px] font-medium text-gray-500 bg-gray-100 rounded">
            {tag}
          </span>
        ))}
      </div>
      
      {/* CTA */}
      <Link 
        to={ctaLink}
        className="inline-flex items-center gap-1 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors group-hover:gap-2"
      >
        {cta} <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
};

// IBM-Style Abstract Pattern Component - Uses Carbon Pictograms
const AbstractPattern = ({ type }: { type: string }) => {
  const pictograms: Record<string, React.ReactNode> = {
    mlops: <DataScience className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    aiops: <EventAutomation className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    agents: <Robotics className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    edge: <EdgeComputing className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    iot: <DataScience className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    finops: <EventAutomation className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    observability: <Robotics className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
    cicd: <EdgeComputing className="w-16 h-10 opacity-60 group-hover:opacity-80 transition-opacity" />,
  };
  
  return pictograms[type] || pictograms.mlops;
};

// IBM-Style Flip Card for Future Services
interface FlipCardProps {
  pattern: string;
  title: string;
  description: string;
  tags: string[];
  ctaLink: string;
  badge?: string;
}

const FlipCard = ({ pattern, title, description, tags, ctaLink, badge }: FlipCardProps) => {
  return (
    <Link 
      to={ctaLink}
      className="group relative h-56 bg-white hover:bg-blue-600 transition-all duration-300 p-4 rounded-sm overflow-hidden cursor-pointer block text-blue-600 group-hover:text-white"
    >
      {/* Header - Always visible */}
      <div className="flex items-start justify-between gap-2 relative z-10">
        <h3 className="text-base font-semibold text-gray-900 group-hover:text-white transition-colors leading-tight">
          {title}
        </h3>
        {badge && (
          <span className="text-[9px] px-1.5 py-0.5 rounded-sm transition-colors whitespace-nowrap flex-shrink-0 bg-gray-100 text-gray-600 group-hover:bg-white/20 group-hover:text-white">
            {badge}
          </span>
        )}
      </div>
      
      {/* Tags - Fixed height for alignment, hides on hover */}
      <div className="absolute inset-x-4 top-14 h-16 group-hover:opacity-0 transition-opacity duration-300">
        <div className="flex flex-wrap gap-1.5">
          {tags.map((tag) => (
            <span 
              key={tag} 
              className="px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] rounded-sm"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      {/* Pattern - Bottom left corner only, hides on hover */}
      <div className="absolute bottom-4 left-4 w-16 h-10 group-hover:opacity-0 transition-opacity duration-300">
        <AbstractPattern type={pattern} />
      </div>
      
      {/* Prominent Arrow - Bottom right corner, always visible */}
      <div className="absolute bottom-4 right-4 z-10">
        <div className="w-10 h-10 rounded-sm bg-blue-50 flex items-center justify-center group-hover:bg-white/20 transition-colors">
          <ArrowRight className="w-5 h-5 text-blue-600 group-hover:text-white transition-colors" />
        </div>
      </div>
      
      {/* Description - Hover state only (no tags) */}
      <div className="absolute inset-x-4 top-14 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <p className="text-xs text-white leading-relaxed">
          {description}
        </p>
      </div>
    </Link>
  );
};

// Custom Services Section
const ServicesVariant = () => {
  return (
    <>
      {/* SECTION 1: Strategic Pillars */}
      <section className="py-20 bg-[#FAFAFA]">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-xs font-medium uppercase tracking-[0.2em] text-blue-500 mb-4 block">
              Built for What Matters
            </span>
            <h2 className="text-4xl sm:text-5xl font-semibold text-[#0F172A] leading-tight tracking-tight mb-4">
              One Partner. Complete Accountability.
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From foundational hardware to AI-driven intelligence.
            </p>
          </div>

          {/* Pillar Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            <ServiceCard
              icon={<BareMetalServer className="w-5 h-5" />}
              title="Infrastructure"
              description={
                <>
                  <p className="font-semibold text-gray-800 mb-2 group-hover:text-blue-700 transition-colors">Leveraging our global alliances, we procure, deploy, and manage the physical assets that power your enterprise.</p>
                  <p className="text-gray-500 max-h-0 opacity-0 overflow-hidden group-hover:max-h-20 group-hover:opacity-100 group-hover:mt-2 transition-all duration-300">From the shipping to the data center floor and final integration, your 24/7 uptime is our absolute accountability.</p>
                </>
              }
              tags={['Server Continuity', 'Data Center', 'Hardware Support', 'Network Operations']}
              cta="Explore Infrastructure"
              ctaLink="/services/infrastructure"
            />
            <ServiceCard
              icon={<Cloud className="w-5 h-5" />}
              title="Cloud"
              description={
                <>
                  <p className="font-semibold text-gray-800 mb-2 group-hover:text-blue-700 transition-colors">Synchronized growth. Digital scale without the integration gap.</p>
                  <p className="text-gray-500 max-h-0 opacity-0 overflow-hidden group-hover:max-h-20 group-hover:opacity-100 group-hover:mt-2 transition-all duration-300">A unified bridge that connects your physical infrastructure to digital scale—zero vendor fragmentation, total operational ownership.</p>
                </>
              }
              tags={['Cost Optimisation', 'DevOps', 'Containers', 'Operations']}
              cta="Explore Cloud"
              ctaLink="/services/cloud"
            />
            <ServiceCard
              icon={<Ai className="w-5 h-5" />}
              title="AI"
              description={
                <>
                  <p className="font-semibold text-gray-800 mb-2 group-hover:text-blue-700 transition-colors">Break out of 'Pilot Purgatory' with hardware-integrated AI.</p>
                  <p className="text-gray-500 max-h-0 opacity-0 overflow-hidden group-hover:max-h-20 group-hover:opacity-100 group-hover:mt-2 transition-all duration-300">We engineer MLOps into your hardware foundation, moving AI from experimental pilots to production-grade assets.</p>
                </>
              }
              tags={['MLOps', 'AI Consulting', 'Data Observability', 'Model Training']}
              cta="Explore AI"
              ctaLink="/services/ai"
            />
          </div>
        </div>
      </section>

      {/* SECTION 2: Engineering for the Future */}
      <section className="py-20 bg-[#0A2C50]">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="text-xs font-medium uppercase tracking-[0.2em] text-blue-400 mb-4 block">
              Extend Your Partnership
            </span>
            <h2 className="text-4xl sm:text-5xl font-semibold text-white leading-tight tracking-tight mb-4">
              Engineering for the Future
            </h2>
            <p className="text-lg text-blue-200 max-w-2xl mx-auto">
              Scaling capabilities without scaling complexity.
            </p>
          </div>

          {/* Future Services - IBM-Style 2x4 Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <FlipCard
              pattern="mlops"
              title="MLOps"
              description="End-to-end machine learning operations from development to production deployment."
              tags={['Model Deployment', 'Pipeline Automation', 'Governance']}
              ctaLink="/services/mlops"
              badge="Emerging"
            />
            <FlipCard
              pattern="aiops"
              title="AIOps"
              description="AI-driven operations that automatically detect anomalies and correlate events."
              tags={['Anomaly Detection', 'Event Correlation', 'Automation']}
              ctaLink="/services/aiops"
              badge="Emerging"
            />
            <FlipCard
              pattern="agents"
              title="AI Agents"
              description="Autonomous systems that execute complex workflows without human intervention."
              tags={['LLM', 'Autonomous Workflows', 'Agents']}
              ctaLink="/services/ai-agents"
              badge="Emerging"
            />
            <FlipCard
              pattern="edge"
              title="Edge Computing"
              description="Process data where it's generated. Reduce latency, improve reliability."
              tags={['IoT', 'Low-latency', 'Distributed']}
              ctaLink="/services/edge-computing"
              badge="Emerging"
            />
            <FlipCard
              pattern="iot"
              title="IoT Analytics"
              description="Real-time analytics for connected devices and sensor networks."
              tags={['Streaming Data', 'Real-time', 'Sensors']}
              ctaLink="/services/iot-analytics"
              badge="Emerging"
            />
            <FlipCard
              pattern="finops"
              title="FinOps Maturity"
              description="AI-enabled cost intelligence at scale. Optimise spend across multi-cloud."
              tags={['Cost Intelligence', 'Governance', 'AI']}
              ctaLink="/services/finops"
              badge="Essential"
            />
            <FlipCard
              pattern="observability"
              title="Advanced Observability"
              description="Full-stack observability with distributed tracing and SRE practices."
              tags={['Distributed Tracing', 'SRE', 'Telemetry']}
              ctaLink="/services/advanced-observability"
              badge="Emerging"
            />
            <FlipCard
              pattern="cicd"
              title="K8s-Native CI/CD"
              description="GitOps-driven continuous delivery built for Kubernetes scale."
              tags={['GitOps', 'ArgoCD', 'Helm']}
              ctaLink="/services/kubernetes-cicd"
              badge="Emerging"
            />
          </div>
        </div>
      </section>

      {/* SECTION 3: Operations */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-xs font-medium uppercase tracking-[0.2em] text-indigo-600 mb-4 block">
              24/7 Operations
            </span>
            <h2 className="text-4xl sm:text-5xl font-semibold text-[#0F172A] leading-tight tracking-tight mb-4">
              Observability & Support
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Full-stack monitoring with guaranteed response times.
            </p>
            <p className="text-xl text-indigo-600 font-semibold max-w-2xl mx-auto mt-2">
              We keep your systems running.
            </p>
          </div>

          {/* Operations Cards - Two Column */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Observability Card - Left */}
            <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center">
                  <View className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-indigo-600 uppercase tracking-wide">Platform</p>
                  <h3 className="text-xl font-semibold text-gray-900">Full-Stack Observability</h3>
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Real-time visibility into infrastructure, applications, and logs. Distributed tracing and intelligent alerting across your entire stack.
              </p>
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                  Infrastructure monitoring
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                  Application tracing
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                  Log aggregation
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                  Custom dashboards
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Observability', 'Logging', 'Tracing', 'Alerting'].map(tag => (
                  <span key={tag} className="px-3 py-1 bg-indigo-100 text-indigo-700 text-xs rounded-full">{tag}</span>
                ))}
              </div>
            </div>

            {/* Support Card - Right */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Headphones className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-blue-600 uppercase tracking-wide">Service</p>
                  <h3 className="text-xl font-semibold text-gray-900">24/7 SLA Support</h3>
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Round-the-clock NOC with guaranteed response times. Cross-domain automation and incident management with escalation procedures.
              </p>
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  24/7 NOC coverage
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  Guaranteed response times
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  Cross-domain automation
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  Incident management
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {['24/7 Support', 'AIOps', 'Network Monitoring', 'SLA'].map(tag => (
                  <span key={tag} className="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">{tag}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Featured Case Study - Dark contrast with thumbnail */}
          <div className="bg-slate-900 rounded-xl p-6 md:p-8 relative overflow-hidden">
            {/* Subtle gradient accent */}
            <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-indigo-600/10 to-transparent" />
            
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6 relative">
              {/* Left: Thumbnail */}
              <div className="w-full md:w-48 h-32 bg-slate-800 rounded-lg border border-slate-700 flex-shrink-0 overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-indigo-500/20 via-slate-800 to-blue-500/20 flex items-center justify-center">
                  <Activity className="w-10 h-10 text-indigo-400/50" />
                </div>
              </div>
              
              {/* Middle: Content */}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-3 py-1 bg-indigo-500/20 text-indigo-300 text-xs font-medium rounded-full">Featured Case Study</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Advanced Observability for Stock Exchange</h3>
                <p className="text-slate-400 text-sm mb-4 leading-relaxed">Trading infrastructure monitoring with 99.99% uptime SLA and 30-day immutable audit trail.</p>
                <Link to="/projects/case-study/financial-market-observability" className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 text-sm font-medium transition-colors">
                  Read the full story <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              
              {/* Right: Stats */}
              <div className="flex gap-8 md:gap-10 border-l border-slate-700 pl-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">99.99%</div>
                  <div className="text-xs text-indigo-400 uppercase tracking-wide mt-1">Uptime SLA</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">30d</div>
                  <div className="text-xs text-indigo-400 uppercase tracking-wide mt-1">Audit Trail</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

const HeroVariant = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-[#0F172A] overflow-hidden pt-20">
      {/* Abstract Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-blue-500 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] bg-cyan-500 rounded-full blur-[100px]" />
      </div>
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)',
        backgroundSize: '80px 80px'
      }} />

      <div className="relative w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-16 lg:py-20">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <span className="inline-block text-xs font-semibold uppercase tracking-[0.3em] text-blue-400 mb-6">
            Enterprise IT Solutions
          </span>
          
          {/* Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-[1.1] tracking-tight">
            <span className="block">Unified Systems</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">Absolute Accountability</span>
          </h1>
          
          {/* Sub-Heading */}
          {/* ORIGINAL: font-semibold tracking-tight, multi-color: text-white + text-blue-300 + text-cyan-300 */}
          <p className="text-lg sm:text-xl text-gray-300 mb-5 font-light tracking-wide">
            Hardware Infrastructure. <span className="text-blue-300">Cloud Scalability.</span> <span className="text-cyan-300">AI Intelligence.</span>
          </p>
          
          {/* Body Text */}
          {/* ORIGINAL: text-gray-400 */}
          <div className="max-w-2xl mb-8">
            <p className="text-base sm:text-lg text-gray-300 leading-relaxed">
              By bridging global supply chains with on-the-ground expertise, we engineer the infrastructure that powers your transformation with absolute accountability
            </p>
          </div>
          
          {/* Process Steps */}
          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-8">
            <span>Design</span>
            <span className="text-gray-600">→</span>
            <span>Procure</span>
            <span className="text-gray-600">→</span>
            <span>Deploy</span>
            <span className="text-gray-600">→</span>
            <span>Integrate</span>
            <span className="text-gray-600">→</span>
            <span>Manage</span>
            <span className="text-gray-600">→</span>
            <span className="text-blue-400 font-medium">Optimise</span>
          </div>
          
          {/* CTAs */}
          <div className="flex flex-wrap gap-4">
            <a
              href="#services"
              className="group inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-full hover:from-blue-400 hover:to-blue-500 transition-all duration-300 shadow-lg shadow-blue-500/25"
            >
              Explore Services
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <Link
              to="/about"
              className="group inline-flex items-center gap-3 px-8 py-4 border border-white/20 text-white font-medium rounded-full hover:bg-white/10 transition-all duration-300"
            >
              <img 
                src="/david_headshot.jpg" 
                alt="David Pridmore" 
                className="w-8 h-8 rounded-full object-cover border-2 border-blue-500"
              />
              Meet David Pridmore, CEO & CTO
            </Link>
          </div>
        </div>
        
        {/* Stats */}
        <div className="absolute bottom-24 right-8 lg:right-12 hidden lg:flex gap-12">
          <div className="text-center">
            <div className="text-4xl font-bold text-white">14+</div>
            <div className="text-xs text-gray-500 uppercase tracking-wide mt-1">Years Experience</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-white">50+</div>
            <div className="text-xs text-gray-500 uppercase tracking-wide mt-1">Platforms Deployed</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-white">24/7</div>
            <div className="text-xs text-gray-500 uppercase tracking-wide mt-1">Support Coverage</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500">
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-px h-6 bg-gradient-to-b from-gray-500 to-transparent" />
      </div>
    </section>
  );
};

const Cover = () => {
  return (
    <>
      <Navigation />
      <main>
        <ErrorBoundary fallback={<div className="h-96 bg-gray-50" />}>
          <HeroVariant />
        </ErrorBoundary>
        <ErrorBoundary fallback={<div className="h-32 bg-gray-50" />}>
          <ClientLogos />
        </ErrorBoundary>
        <ErrorBoundary>
          <TrustBar />
        </ErrorBoundary>
        <ErrorBoundary>
          <ServicesVariant />
        </ErrorBoundary>
        <ErrorBoundary>
          <Testimonials />
        </ErrorBoundary>
        <ErrorBoundary>
          <Differentiator />
        </ErrorBoundary>
        <ErrorBoundary>
          <CaseStudies />
        </ErrorBoundary>
        <ErrorBoundary>
          <About />
        </ErrorBoundary>
        <ErrorBoundary>
          <Delivery />
        </ErrorBoundary>
        <ErrorBoundary>
          <Reliability />
        </ErrorBoundary>
        <ErrorBoundary>
          <Partnerships />
        </ErrorBoundary>
        <ErrorBoundary>
          <Closing />
        </ErrorBoundary>
        <ErrorBoundary>
          <Contact />
        </ErrorBoundary>
      </main>
      <Footer />
    </>
  );
};

export default Cover;
